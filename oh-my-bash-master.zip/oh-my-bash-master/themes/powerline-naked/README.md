# Powerline Naked Theme

A simple theme derived from the Powerline theme.

This is based on the Powerline theme. Please see also [the documentation of the
powerline theme](../powerline/README.md).

![Screenshot](./powerline-naked-dark.png?raw=true)
