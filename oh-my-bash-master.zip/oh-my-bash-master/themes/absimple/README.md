# ab+simple theme

This theme needs a Powerline-patched font to be rendered correctly. The original author of the theme recommends https://github.com/adi1090x/termux-style

This is a colorful theme based on the agnoster theme, made shorter and simpler.

The aim of this theme is to only show you relevant information:
The git information will only be shown in a git working directory.
Similarly, everything will be displayed automatically when appropriate,
including the current user and the hostname,
whether the last call exited with an error,
and whether background jobs are running in this shell.

![bash screenshot](absimple-bash.png)
