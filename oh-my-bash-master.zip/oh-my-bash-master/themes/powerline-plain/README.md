# Powerline Plain Theme

A simplified version of the Powerline theme.

This is based on the Powerline theme. Please see also [the documentation of the
powerline theme](../powerline/README.md). This theme does not require a font
with the Powerline symbols as required in the original Powerline theme.

![Screenshot](./powerline-plain-dark.png?raw=true)
