# Axin

![Theme Axin](axin-dark.png)

Axin Bash Prompt, inspired by theme "Sexy" and "Bobby"
