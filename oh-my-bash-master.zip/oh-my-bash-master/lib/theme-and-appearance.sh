#! bash oh-my-bash.module

# colored ls
export LSCOLORS='Gxfxcxdxdxegedabagacad'
