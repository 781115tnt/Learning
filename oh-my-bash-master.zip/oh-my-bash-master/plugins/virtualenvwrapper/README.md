# virtualenvwrapper plugin

The virtualenvwrapper plugin enables virtualenvwrapper functions in bash.

To use it, install
[virtualenvwrapper](https://github.com/python-virtualenvwrapper/virtualenvwrapper) and add
virtualenvwrapper to the plugins array of your bashrc file:

```bash
plugins=(... virtualenvwrapper)
```
