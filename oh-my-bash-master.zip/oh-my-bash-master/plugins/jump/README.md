# jump plugin

The jump plugin enables jump on bash.

To use it, install
[jump](https://github.com/gsamokovarov/jump?tab=readme-ov-file#installation)
and add jump to the plugins array of your bashrc file:

```bash
plugins=(... jump)
```
