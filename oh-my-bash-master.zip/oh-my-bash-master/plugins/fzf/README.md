# fzf plugin

The fzf plugin enables fzf keybindings and completions on bash.

To use it, install
[fzf](https://github.com/junegunn/fzf?tab=readme-ov-file#installation) and add fzf
to the plugins array of your bashrc file:

```bash
plugins=(... fzf)
```
