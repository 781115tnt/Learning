# bash preexec

This plugin loads `bash-preexec.sh` bundled with OMB if necessary.
