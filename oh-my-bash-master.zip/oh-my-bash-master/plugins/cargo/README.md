# cargo plugin

This plugin configures cargo paths.
