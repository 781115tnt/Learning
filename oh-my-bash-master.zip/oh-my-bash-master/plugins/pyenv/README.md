# pyenv plugin

The pyenv plugin will configure pyenv paths.
