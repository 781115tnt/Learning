(() => {
  const color = "#1e1e1e"; // your custom title bar color (dark gray)

  // Wait for <head> if it's not ready
  if (document.head) {
    inject();
  } else {
    new MutationObserver((_, obs) => {
      if (document.head) {
        inject();
        obs.disconnect();
      }
    }).observe(document.documentElement, { childList: true });
  }

  function inject() {
    let meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'theme-color';
      document.head.appendChild(meta);
    }
    meta.content = color;
  }
})();

