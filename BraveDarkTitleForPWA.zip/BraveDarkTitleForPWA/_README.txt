1. Open Brave -> Settings -> Manage Extension
2. Enable Development
3. Load extension folder