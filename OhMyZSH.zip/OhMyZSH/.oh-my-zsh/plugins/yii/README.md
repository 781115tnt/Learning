# Yii plugin

The plugin adds autocomplete commands and subcommands for [yii](https://www.yiiframework.com/).

To use it, add `yii` to the plugins array of your zshrc file:

```zsh
plugins=(... yii)
```

## Aliases

| Alias  | Command              |
|--------|----------------------|
| yiic   | `protected/yiic`     |
